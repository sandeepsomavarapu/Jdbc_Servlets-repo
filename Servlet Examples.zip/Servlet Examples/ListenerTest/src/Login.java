import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Login extends HttpServlet 
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
	PrintWriter out=response.getWriter();
	
	request.setAttribute("name", "welcome");
	
	HttpSession session=request.getSession();
	
	String name1=request.getParameter("name");
	String password1=request.getParameter("password");

	if(password1. equals("sandeep"))
	{
		request.setAttribute("name", "welcome1");
		HttpSession session1=request.getSession();
		
			session1.setAttribute("username",name1);
			session1.setAttribute("password",password1);
			out.println("login success");
	}
	else
	{
		System.out.println("enter valid password");
	}
			out.println("<a href='Logout'>Logout</a>");
	}
}
