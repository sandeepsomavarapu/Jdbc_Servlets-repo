import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;
public class Test1 implements HttpSessionAttributeListener {
    public void attributeAdded(HttpSessionBindingEvent arg0)  { 
         System.out.println("Attribute Added to Session object");
    }
    public void attributeRemoved(HttpSessionBindingEvent arg0)  { 
    	System.out.println("Attribute removed from Session object");
    }
    public void attributeReplaced(HttpSessionBindingEvent arg0)  { 
    	System.out.println("Attribute replaced from Session object");
    }
}
