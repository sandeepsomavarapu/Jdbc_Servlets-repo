var a:number=10;
console.log(a);