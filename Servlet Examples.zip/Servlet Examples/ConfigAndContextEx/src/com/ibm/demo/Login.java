package com.ibm.demo;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ServletConfig config = getServletConfig();
		String org = config.getInitParameter("orgname");
		System.out.println("Login Config Data :" + org);
		
		ServletContext context = request.getServletContext();
		String org1=context.getInitParameter("orgname1");
		System.out.println("Login context data :"+ org1);
		
	}

}
