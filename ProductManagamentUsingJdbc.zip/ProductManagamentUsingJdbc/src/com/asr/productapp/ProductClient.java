package com.asr.productapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

//create table products_info(productId int,productName varchar(20),productPrice int,productCategory varchar(20));
public class ProductClient {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ericsson", "root", "rpsconsulting");
		int productId;
		String productName;
		int productPrice;
		String productCategory;
		PreparedStatement psmt;
		int result ;
		System.out.println("**************Product Management Application**********");
		while (true) {
			System.out.println("1.AddProduct");
			System.out.println("2.Update Product");
			System.out.println("3.Delete Product");
			System.out.println("4.Get Product");
			System.out.println("5.Get All Products");
			System.out.println("6.Get All Products InBetween Prices");
			System.out.println("7.Exit");

			Scanner scan = new Scanner(System.in);
			int option = scan.nextInt();

			switch (option) {
			case 1:
				System.out.println("Add Product");
				System.out.println("Enter Product id");
				productId = scan.nextInt();
				System.out.println("Enter product Name");
				productName = scan.next();
				System.out.println("Enter Product Price");
				productPrice = scan.nextInt();
				System.out.println("Enter product Category");
				productCategory = scan.next();
				
				psmt = conn.prepareStatement("insert into products_info values(?,?,?,?)");
				psmt.setInt(1, productId);
				psmt.setString(2, productName);
				psmt.setInt(3, productPrice);
				psmt.setString(4, productCategory);
				
				 result = psmt.executeUpdate();
				if (result > 0)
					System.out.println("Product Added Successfully... ");
				break;
			case 2:
				System.out.println("Update Product");
				System.out.println("Enter Exsisting Product id");
				productId = scan.nextInt();
				System.out.println("Enter product Name");
				productName = scan.next();
				System.out.println("Enter Product Price");
				productPrice = scan.nextInt();
				System.out.println("Enter product Category");
				productCategory = scan.next();
				
				psmt = conn.prepareStatement("update products_info set productName=?,productPrice=?,productCategory=? where productId=?");
				
				psmt.setString(1, productName);
				psmt.setInt(2, productPrice);
				psmt.setString(3, productCategory);
				psmt.setInt(4, productId);
				
				 result = psmt.executeUpdate();
				if (result > 0)
					System.out.println("Product Updated Successfully... ");
				break;
			case 3:
				System.out.println("Delete Product");
				System.out.println("Enter Exsisting Product id for delete");
				productId = scan.nextInt();
				psmt = conn.prepareStatement("delete from products_info where productId=?");
				psmt.setInt(1, productId);
				result = psmt.executeUpdate();
				if (result > 0)
					System.out.println("Product Deleted Successfully... ");
				break;
			case 4:
				System.out.println("Get Product");
				System.out.println("Enter Exsisting Product id");
				productId = scan.nextInt();
				psmt = conn.prepareStatement("select * from products_info where productId=?");
				psmt.setInt(1, productId);
				ResultSet rs = psmt.executeQuery();
				if (rs.next())
					System.out.println("Product Info: ");
					System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getString(4) );
				break;
			case 5:
				System.out.println("Products Info..");
				psmt = conn.prepareStatement("select * from products_info ");
			
				 rs = psmt.executeQuery();
				while (rs.next()) {
					System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getString(4) );
				}
				break;
			case 6:
				System.out.println("Enter Product IntialPrice");
				int productIntialPrice = scan.nextInt();
				System.out.println("Enter Product FinalPrice");
				int productFinalPrice = scan.nextInt();
				psmt = conn.prepareStatement("select * from products_info where productPrice between ? and ? ");
				psmt.setInt(1, productIntialPrice);
				psmt.setInt(2, productFinalPrice);
				 rs = psmt.executeQuery();
					while (rs.next()) {
						System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getString(4) );
					}
					break;
			default:
				scan.close();
				conn.close();
				System.out.println("Thank You !!!");
				System.exit(0);
				break;
			}
		}
	}

}