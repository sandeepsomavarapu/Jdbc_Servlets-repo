package Other.listeners;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

public class Test implements ServletContextListener 
{

	   public void contextInitialized(ServletContextEvent sec) 
	   { 
	   
		   System.out.println("application-initialized");
	   
	   }  
    public void contextDestroyed(ServletContextEvent sec)  
    { 
    	   System.out.println("application-destroyed");
    }

 
}
