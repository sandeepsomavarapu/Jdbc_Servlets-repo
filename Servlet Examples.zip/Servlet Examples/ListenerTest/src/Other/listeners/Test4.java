package Other.listeners;
import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;


public class Test4 implements ServletRequestAttributeListener 
{
	public void attributeAdded(ServletRequestAttributeEvent arg0) {
		
		System.out.println("attribute added");
	}
	public void attributeRemoved(ServletRequestAttributeEvent arg0) {
		System.out.println("attribute removed");
	}
	public void attributeReplaced(ServletRequestAttributeEvent arg0) {
		System.out.println("attribute replaced");
		
	}

}
