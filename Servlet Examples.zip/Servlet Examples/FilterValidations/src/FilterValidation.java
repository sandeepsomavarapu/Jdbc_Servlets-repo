import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
public class FilterValidation implements Filter 
{   public void init(FilterConfig fConfig) throws ServletException 
	{
		//String value = fConfig.getInitParameter("key");
	}
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException 
	{
		PrintWriter pw = response.getWriter();
		String name = request.getParameter("sname");
		String email = request.getParameter("email");	
		int marks = 0;
		try 
		{
			marks = Integer.parseInt(request.getParameter("marks"));
		} catch (Exception e) {
			System.out.println("please enter only numeric values");
		}
		if (name.equals("")) {
			pw.println("name is required");
		}
		if (email.equals("")) {
			pw.println("email required");
		}
		if (marks == 0) {
			pw.println("marks required");
		} else {
			pw.println("<pre>");		
			
			chain.doFilter(request, response);	
			
			pw.println("</pre>");
			pw.println("<body bgcolor='red'>");
			pw.println("<h1>after servlet execution</h1>");
			pw.println("</body>");
		}
	}
	public void destroy() {
		System.out.println("filter destroy");
	}

}
