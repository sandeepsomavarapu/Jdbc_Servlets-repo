package Other.listeners;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;


public class Test3 implements ServletRequestListener {

   
	
    public void requestInitialized(ServletRequestEvent sre)  
    { 

        System.out.println("for each request init");
 
    }
    public void requestDestroyed(ServletRequestEvent sre)  
    { 
        System.out.println("for each request destroyed");
        
    }

	
}
