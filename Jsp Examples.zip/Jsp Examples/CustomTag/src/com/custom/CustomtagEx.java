package com.custom;
import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class CustomtagEx extends SimpleTagSupport  
{
   public void doTag() throws JspException, IOException 
   {
      JspWriter out = getJspContext().getOut();//printwriter
      out.println("This tag is created by user-custom tag");
   }
}


/*javax.servlet.jsp.Tagext.Tag

javax.servlet.jsp.Tagext.BodyTaginterface 
javax.servlet.jsp.Tagext.IterationTag

/WEB-INF/classes/<package-directory-structure>

javax.servlet.jsp.Tagext.TagSupport
javax.servlet.jsp.Tagext.BodyTagSupportclass
javax.servlet.jsp.tagext.SimpleTagSupport
*/